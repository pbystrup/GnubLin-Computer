#include "average_filter.h"

AverageFilter::AverageFilter(){

}

AverageFilter::~AverageFilter(){

}

