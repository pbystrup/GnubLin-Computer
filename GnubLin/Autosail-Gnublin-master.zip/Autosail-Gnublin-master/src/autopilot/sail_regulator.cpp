#include "sail_regulator.h"

SailRegulator::SailRegulator(){

}

SailRegulator::~SailRegulator(){

}

