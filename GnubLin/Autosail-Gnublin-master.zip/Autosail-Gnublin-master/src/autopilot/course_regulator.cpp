#include "course_regulator.h"

CourseRegulator::CourseRegulator(){

}
CourseRegulator::~CourseRegulator(){

}
