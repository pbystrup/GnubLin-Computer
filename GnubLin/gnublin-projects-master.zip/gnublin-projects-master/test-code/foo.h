//void foo ( struct test *tobi);

struct test {
	int a;
	int b;
};

//void foo ( );
void foo ( struct test *tobi );
