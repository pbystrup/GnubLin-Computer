
extern void IRfreqGen();

