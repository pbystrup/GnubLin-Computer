/** \file */

extern int FrequOut(char gpio[3], unsigned long int Freq, int count);
