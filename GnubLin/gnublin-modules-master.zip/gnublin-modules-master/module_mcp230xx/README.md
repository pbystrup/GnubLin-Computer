Summary
-------

This module support the MCP23017 and MCP23009 chips. The MCP23017 device provide a 16 bit general purpose parallel I/O expansion for I2C bus and the MCP23009 device provide a 8 I/Os instead of 16.


Installation
------------

See the README file of the upper directory for installation instructions.


Code Samples
------------

Coming soon