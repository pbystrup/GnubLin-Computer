Summary
-------

This module allow to read temperature and relative humidity from a SHT2X sensor from sensirion.

Installation
------------

See the README file of the upper directory for installation instructions.

Code Samples
------------

Coming soon.