#!/bin/bash

./setenv.sh
cd linux*
make menuconfig
