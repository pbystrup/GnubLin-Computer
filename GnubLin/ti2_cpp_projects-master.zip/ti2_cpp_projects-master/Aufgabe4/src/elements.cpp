#include "elements.h"

void Elements::Set_Value( double newValue )
{
    value = newValue;
}
