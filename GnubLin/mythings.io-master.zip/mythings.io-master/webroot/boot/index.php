<?
header("Location: http://www.ixbat.de/index.php?page_id=81");
?>
