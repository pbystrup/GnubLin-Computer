<?

// Database connection
$db[user] = "unishop";
$db[name] = "unishop";
$db[pass] = "SUh8q2=mP";
$db[host] = "localhost";

?>
