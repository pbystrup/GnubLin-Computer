<?

$_SERVER[PHP_AUTH_PW] = "hallo";

?>
