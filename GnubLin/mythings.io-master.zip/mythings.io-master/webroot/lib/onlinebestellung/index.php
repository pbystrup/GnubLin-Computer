<?


print_r(get_browser());




?>
