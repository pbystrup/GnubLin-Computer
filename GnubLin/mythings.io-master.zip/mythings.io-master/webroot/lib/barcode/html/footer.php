<?php
if(!defined('IN_CB'))die('You are not allowed to access to this page.');
?>

<p style="text-align:center;font-size:10px">
All Rights Reserved &copy; 2004-2009 <a href="http://www.barcodephp.com" target="_blank">Barcode Generator</a> PHP4-v<?php echo constant('VERSION'); ?>
<br />by Jean-S�bastien Goupil
</p>

</body>
</html>