<?php
header('Location: code39.php');
?>