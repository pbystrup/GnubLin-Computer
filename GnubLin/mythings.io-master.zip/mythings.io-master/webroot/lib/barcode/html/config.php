<?php
$class_dir = '/home/eproo/www/eprooSystem/webroot/lib/barcode/class';
?>
