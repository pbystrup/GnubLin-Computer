#!/bin/bash

export PATH=$PATH:/home/eproo/www/eprooSystem/pygen/formgen:/home/eproo/www/eprooSystem/pygen/apigen:/home/eproo/www/eprooSystem/pygen:/home/eproo/www/eprooSystem/pygen/pagegen

export PWD=/home/eproo/www/eprooSystem/webroot

export PYTHONPATH=$PYTHONPATH:/home/eproo/www/eprooSystem/pygen/formgen:/home/eproo/www/eprooSystem/pygen/apigen

