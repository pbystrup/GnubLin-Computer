


#ifndef CONFIGURATION_H
#define CONFIGURATION_H
#include "configuration.h"
#endif

void daemonRun(Settings * settings, int argc, char **argv);
