<?php
header("Location: ./www/index.php");
?>