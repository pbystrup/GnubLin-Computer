ALTER TABLE `emailbackup_mails` ADD INDEX ( `checksum` ) ;
