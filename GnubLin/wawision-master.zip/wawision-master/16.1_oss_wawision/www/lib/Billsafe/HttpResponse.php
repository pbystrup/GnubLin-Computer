<?php

class Billsafe_HttpResponse
{
    public $statusCode;
    public $statusText;
    public $contentType;
    public $contentLength;
    public $body;
}