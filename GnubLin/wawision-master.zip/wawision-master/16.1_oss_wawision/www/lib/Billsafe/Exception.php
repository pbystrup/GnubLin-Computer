<?php

class Billsafe_Exception extends Exception
{
    
}