#!/bin/bash
/usr/bin/php -q /home/eproo/eproo-master/app/main/cronjobs/hourly.php
