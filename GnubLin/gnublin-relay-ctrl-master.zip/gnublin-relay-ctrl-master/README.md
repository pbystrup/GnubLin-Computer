gnublin-relay-ctrl
==================

Simple GUI to control a gnublin relay.

to install do `npm install` in root, and then run `sails lift` to launch dev mode.

