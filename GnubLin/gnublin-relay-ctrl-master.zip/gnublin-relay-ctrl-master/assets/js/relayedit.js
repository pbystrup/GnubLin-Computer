$(function(){
    $("#content").load("/relay/editform");
});
