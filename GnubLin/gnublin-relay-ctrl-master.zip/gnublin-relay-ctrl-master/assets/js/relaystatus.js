$(function(){
    $("#relaystatus").load("/relay/getRelayStatus");
});
