This directory contains the interface for the HY-MiniSTM32V board
running ChibiOS/RT.

If you are using the uGFX makefiles use OPT_CPU=stm32m3 in your makefile to get the correct cpu.

As this is not a standard ChibiOS/RT supported board, the necessary board files have
also been provided in the chibios_board directory

