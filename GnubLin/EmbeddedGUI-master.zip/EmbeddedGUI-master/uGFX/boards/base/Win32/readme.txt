This directory contains the interface for Win32
running either native Win32 or under the ChibiOS simulator.

On this board uGFX currently supports:
	- GDISP via the Win32 driver 
	- GINPUT-touch via the Win32 driver
	- GINPUT-toggles via the Win32 driver

There is an example Makefile and project in the examples directory.
