In order to run this demo you will have to link against the math libs.
You can do this by adding   -lm   to the   LIBS   variable in your Makefile:

    LIBS = -lm
