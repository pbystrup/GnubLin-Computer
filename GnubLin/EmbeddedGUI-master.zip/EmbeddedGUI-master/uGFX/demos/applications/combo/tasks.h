#ifndef _TASKS_INCLUDED
#define _TASKS_INCLUDED

void doMandlebrot(GHandle parent, bool_t start);
void doBounce(GHandle parent, bool_t start);

#endif
