The files in this directory come from 3rdparty sources.
They do not stand under the uGFX licensing terms as they come with their own
licensing model.

No warranty for the correct functionality for this software is given by the
uGFX maintainers.
No official support for this software is provided by the uGFX maintainers.

