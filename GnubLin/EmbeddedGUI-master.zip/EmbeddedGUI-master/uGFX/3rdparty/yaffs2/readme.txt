Yaffs2 source code has not been included in this repository so that you are fully
aware of the license restrictions before using it with uGFX.

Yaffs2 may be downloaded from http://www.yaffs.net 
 
This notice has been provided in collaboration with Aleph One - the owners of Yaffs2.
As such it represents an agreement of understanding between Aleph One and uGFX.
 
Yaffs2 is distributed under the GPLv2 license. Specifically that means the following�
-	You may publish the source code for your project including the yaffs2 and uGFX code
        provided that you retain the respective licenses and copyrights in the header
        of each source file.
-	You may create a binary for your own personal use.
-	You MUST NOT distribute a binary that you produce in any form (even in the ROM of
        a device) that contains both yaffs2 and uGFX code as that will put you in
        breach of either the GPL license or the uGFX license no matter what you do.
        See http://ugfx.org/licensing for more details.
-	Regardless of whether the project is commercial or non-commercial, you MUST NOT
        even compile binaries for other people since that is considered "distribution".
        You cannot even compile binaries for a friend, they must build it for themselves.
 
If you want to distribute a binary that contains both yaffs2 and uGFX (even in the
ROM of a device) then you must obtain a commercial license of yaffs2 just as you must
obtain a commercial license for uGFX if you want to use it for commercial purposes.
 
Just as uGFX provides special licenses for certain open hardware projects, Aleph One
may consider providing special licenses for various special purposes. Please contact
Aleph One at info@aleph1.co.uk for more information.
