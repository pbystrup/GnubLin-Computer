gnublin-installer
=================

Dependencies:

- libcurl3-dev
- libparted0-dev
- libparted0debian1
- libwxgtk2.8-dev

`sudo apt-get install libcurl3-dev libparted0-dev libparted0debian1 libwxgtk2.8-dev gawk g++`
