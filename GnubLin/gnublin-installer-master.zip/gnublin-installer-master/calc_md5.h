#ifndef _CALC_MD5_H_
#define _CALC_MD5_H_

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <iostream>
#include <fstream>


char* calc_md5(char* filename);

#endif
