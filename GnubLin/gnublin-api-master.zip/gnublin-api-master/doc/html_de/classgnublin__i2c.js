var classgnublin__i2c =
[
    [ "gnublin_i2c", "classgnublin__i2c.html#a0d66972535c8e90428f23ece76f3ac65", null ],
    [ "gnublin_i2c", "classgnublin__i2c.html#aacd835a2ae3c5e378caeff52290c40c8", null ],
    [ "gnublin_i2c", "classgnublin__i2c.html#a29155f7b8901bbc79b29139de7967670", null ],
    [ "~gnublin_i2c", "classgnublin__i2c.html#aa3cd977780c3d1416d990079701ccdcc", null ],
    [ "fail", "classgnublin__i2c.html#a4413c9510eb70ad05b8226771a3c9d32", null ],
    [ "getAddress", "classgnublin__i2c.html#ad8c8cd7ad86ed683da287461bb3684ef", null ],
    [ "getErrorMessage", "classgnublin__i2c.html#a958605de39dd949027b8b9913ac78ec1", null ],
    [ "receive", "classgnublin__i2c.html#a1a5aa8a33747395fc037e09527f138b5", null ],
    [ "receive", "classgnublin__i2c.html#a1444ef0460cc6f5e68df8d279007a9db", null ],
    [ "send", "classgnublin__i2c.html#a494281d965dc96b7d59e75882da3ba0e", null ],
    [ "send", "classgnublin__i2c.html#a9d03378f65c830904067ec2e788c62bb", null ],
    [ "send", "classgnublin__i2c.html#af61764bb1284d00ac9d8dd61217acbe5", null ],
    [ "setAddress", "classgnublin__i2c.html#a90a93e09d54776eea8672f0bfe420682", null ],
    [ "setDevicefile", "classgnublin__i2c.html#a181a9cfd2156dab527f88dcd9507fb2e", null ]
];