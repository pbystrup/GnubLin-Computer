var classgnublin__module__lm75 =
[
    [ "gnublin_module_lm75", "classgnublin__module__lm75.html#afa8943ed3f140b8acd37a8a683ad43c1", null ],
    [ "fail", "classgnublin__module__lm75.html#ad628c7dd8ad16585f42b7601b56fdd10", null ],
    [ "getErrorMessage", "classgnublin__module__lm75.html#aa5efb67553533a84d9b4b71b7541265c", null ],
    [ "getTemp", "classgnublin__module__lm75.html#af68c7031cfa9fdd6d592df3d0a6f482d", null ],
    [ "getTempFloat", "classgnublin__module__lm75.html#aa64b578d8847ac28abdd0aa2ab86855b", null ],
    [ "getValue", "classgnublin__module__lm75.html#a65168fbb03782fa3b82e8448b9769929", null ],
    [ "setAddress", "classgnublin__module__lm75.html#a62c5af59cf2db400e64174b019e6494c", null ],
    [ "setDevicefile", "classgnublin__module__lm75.html#a363716d889c320f202abe5d35479c4de", null ]
];