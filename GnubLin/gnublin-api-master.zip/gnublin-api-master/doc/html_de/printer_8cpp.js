var printer_8cpp =
[
    [ "initMotor", "printer_8cpp.html#ab58f6df01b023e10f18790c8528e1bb8", null ],
    [ "initPrinter", "printer_8cpp.html#a5ae1b5eda4c278af3b9e2535e4581be9", null ],
    [ "main", "printer_8cpp.html#a3c04138a5bfe5d72780bb7e82a18e627", null ],
    [ "my_handler", "printer_8cpp.html#a13848d945610347db87a059fe0b43f35", null ],
    [ "parse_opts", "printer_8cpp.html#a624b285f42b0c50d7f3f45c15415f25e", null ],
    [ "print", "printer_8cpp.html#aaf10537341632583e9f682d8106e3581", null ],
    [ "print_x_slow", "printer_8cpp.html#ac8bfafabc4847266997830b6bab23865", null ],
    [ "print_z_slow", "printer_8cpp.html#a6f8b87d85189ba582525df030d02a3ca", null ],
    [ "hflag", "printer_8cpp.html#a6fe8b762116512ab777118cd3e043200", null ],
    [ "initflag", "printer_8cpp.html#a37b318383ca653e8042174ab53cfb827", null ],
    [ "Motor_p", "printer_8cpp.html#a624ce311cff0a390ba82d5b1353e51e1", null ],
    [ "Motor_x", "printer_8cpp.html#a1def7fd6c8b475fb7165aa3d5154f42f", null ],
    [ "Motor_y", "printer_8cpp.html#a7e6460d70c02565e99c42406b91c57ab", null ],
    [ "Motor_z", "printer_8cpp.html#ae6750763e79f3505e096ad1d6c94d621", null ],
    [ "printflag", "printer_8cpp.html#ac8c5f0b30e4d973e04955a2109522be9", null ]
];