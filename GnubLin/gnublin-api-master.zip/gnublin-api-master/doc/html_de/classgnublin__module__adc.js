var classgnublin__module__adc =
[
    [ "gnublin_module_adc", "classgnublin__module__adc.html#aeaf9541603d446cb00351fc4534f368b", null ],
    [ "fail", "classgnublin__module__adc.html#a7fdcd19426bff46830d9d3a66733fa77", null ],
    [ "getErrorMessage", "classgnublin__module__adc.html#ab17ba4ceae7dbf0a6112ef839b531465", null ],
    [ "getValue", "classgnublin__module__adc.html#adec34fe461abb18645d9db55e8331daa", null ],
    [ "getValue", "classgnublin__module__adc.html#a5b1f31eaf30c3963c91f642aee9ec472", null ],
    [ "getVoltage", "classgnublin__module__adc.html#a7cbc21844232dcedd48ee38cd005ac9e", null ],
    [ "getVoltage", "classgnublin__module__adc.html#af557e19a606b69c9526109f8727f8639", null ],
    [ "setAddress", "classgnublin__module__adc.html#a4b064d1a5a77ca70cde76355fda5954f", null ],
    [ "setDevicefile", "classgnublin__module__adc.html#abec8ea6ec294f61ab526afd64712f15d", null ],
    [ "setReference", "classgnublin__module__adc.html#a9f0a034f2188edfa7e7469311a4e05eb", null ]
];