var classgnublin__adc =
[
    [ "gnublin_adc", "classgnublin__adc.html#a691a2d62e096d5e7070c214912bd280b", null ],
    [ "fail", "classgnublin__adc.html#a8c3276ec8b481920fecf246a2f946509", null ],
    [ "getErrorMessage", "classgnublin__adc.html#ad6a0b1fa3c832ce153624780d96ece6b", null ],
    [ "getValue", "classgnublin__adc.html#a3567d63d6c24be2fdc895183f6509d42", null ],
    [ "getVoltage", "classgnublin__adc.html#a0e075bd9dbab25f2a265ed199a486c32", null ],
    [ "setReference", "classgnublin__adc.html#a6d094a0e5fef2d6c65c60a8fa3f0f441", null ]
];