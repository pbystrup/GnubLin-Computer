#ifndef DEFINES_H
#define DEFINES_H

#define LINES 4
#define ROWS 20
enum State { MAIN, TITLE, WHO, DESCRIPTION, TIME, PRINT };
#endif
