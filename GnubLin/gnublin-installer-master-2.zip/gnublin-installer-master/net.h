#ifndef _NET_H_
#define _NET_H_

int get_file(const char* url, const char* destination);


#endif

