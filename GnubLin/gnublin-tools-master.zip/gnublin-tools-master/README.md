Summary
-------

The tools are designed to easily interact with the [gnublin modules][1]. A tool exist for each module.

Installation
------------

The gnublin modules must be compiled and installed. See the [README][2] file for further instructions about installing the modules. When the modules are installed, type the following command for installing the tools.

    git clone https://github.com/cburki/gnublin-tools.git
    cd gnublin-tools
    make
    make publish


  [1]: https://github.com/cburki/gnublin-modules
  [2]: https://github.com/cburki/gnublin-modules/blob/master/README.md